﻿using System.Collections.Generic;
using Assigment1.Models;

namespace Assigment1.Data
{
    public interface IUsersData
    {
        IList<User> GetUsers();
        void AddUser(User user);
    }
}