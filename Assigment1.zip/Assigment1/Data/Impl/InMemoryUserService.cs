﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using Assigment1.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.VisualBasic;

namespace Assigment1.Data
{
    public class InMemoryUserService : IUserService
    {
        private List<User> users;

        public InMemoryUserService()
        {
            users = new[]
            {
                new User
                {
                    FirsName = "Eugen",
                    LastName = "Mihai",
                    HairColor = "Brown",
                    EyeColor = "Brown",
                    Age = "32",
                    Weight = "90",
                    Height = "180",
                    Sex = "Male"
                },

                new User
                {
                    FirsName = "Teo",
                    LastName = "Mihai",
                    HairColor = "Brown",
                    EyeColor = "Brown",
                    Age = "55",
                    Weight = "60",
                    Height = "160",
                    Sex = "Female"
                }
            }.ToList();
        }

        public User ValidateUser(string userName, string Password)
        {
            throw new NotImplementedException();
        }
    }

   
    

    internal class Password
    {
    }

    internal class password
    {
    }

    internal class userName
    {
    }

    public class users
    {
    }

    public class first
    {
    }

    public User ValidateUser(string userName, string Password)
        {
        User first = users.FirstOrDefault(users => users.UserName.Equals(userName));
        if (first == null)
        {
            throw new Exception("User not found");
        }
        if (!first.Password.Equals(password))
        {
            throw new Exception("Incorrect password");
        }
            return first;
        }
}*/