﻿using Assigment1.Models;

namespace Assigment1.Data
{
    public interface IUserService
    {
        User ValidateUser(string userName, string Password);
    }
}