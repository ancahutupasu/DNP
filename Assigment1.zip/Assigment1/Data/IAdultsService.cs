﻿namespace Assigment1.Data
{
public class IAdultsService
{
        
}
}