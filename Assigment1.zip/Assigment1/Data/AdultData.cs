﻿/*using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Assigment1.Models;
using Assigment1.Persistence;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;

namespace Assigment1.Data
{
    public class AdultData : IAdultData
    {
        private FileContext FileContext()
        {
            throw new NotImplementedException();
        }

        public AdultData()
        {
            FileContext = new FileContext();
        }

        public IList<Adult> GetAdults()
        {
            return FileContext.Adults;
        }

        public void AddAdult(Adult newAdult)
        {
            FileContext.Adults.Add(newAdult);
            FileContext.SaveChanges();
        }

        public void RemoveAdult(int adultId)
        {
            FileContext.Adults.Remove(adultId);
            FileContext.SaveChanges();
        }

        public void UpdateAdult(Adult adult)
        {
            Adult toUpdate = FileContext.Adults.First(ToString() => toUpdate.Id== adult.Id);
            FileContext.Adults.Remove(toUpdate);
            FileContext.Adults.Add(adult);
            FileContext.SaveChanges();
        }

        public Adult GetAdult(int id)
        {
            return FileContext.Adults.First(t => t.Id == id);
        }
        
        *public List<Adult> SearchFilter(string searchNyName)
        {
            var adultsTotal = FileContext.Adults.Where(this =>
            object t;
            (!searchNyName.Equals("") &&
             (t.FirstName.Contains(searchNyName,
                  StringComparison.OrdinalIgnoreCase) ||
              t.LastName.Contains(searchNyName, StringComparison.OrdinalIgnoreCase) || searchNyName.Equals(""))).ToList();
        var ordered<Adult> =
        adultsTotal.OrderBy(t: Adult => t.Id).ToList();
            
            
            
            
            
            
            
            
        private void SearchByName(ChangeEventArgs changeEventArgs)
        {
            SearchByName = null;
            try
            {
                SearchByName = changeEventArgs.Value.ToString();
            }
            catch (Exception)
            {
            }
            ExecuteFilter();

    }


        private void ExecuteFilter()
        {
            throw new NotImplementedException();
        }*/