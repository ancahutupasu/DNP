﻿namespace Assigment1.Data
{
    public interface IAdultData
    {
        
    }
}