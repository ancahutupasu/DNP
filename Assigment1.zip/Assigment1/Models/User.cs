﻿namespace Assigment1.Models
{
    public class User
    {
        public string UserName { get; set; }
        public string FirsName { get; set; }
        public string LastName { get; set; }
        public string HairColor { get; set; }
        public string EyeColor { get; set; }
        public string Age { get; set; }
        public string Weight { get; set; }
        public string Height { get; set; }
        public string Sex { get; set; }
        public string JobTitle { get; set; }
        public int Salary { get; set; }
    }
}