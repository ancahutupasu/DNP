﻿namespace Assigment1.Models
{
    public class Adult : Person
    {
        public Job JobTitle { get; set; }
    }
    
}
